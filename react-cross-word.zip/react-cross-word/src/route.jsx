import React from 'react'
import {
  HashRouter as Router,
  Route,
  } from 'react-router-dom';
import Home from './components/home';
import Results from './components/results';


const Routes =() => (
    
    <Router basename="">
    <div>
     
      <Route exact path="/" component={Home} />
      <Route path="/article/:id" component={Results} />
     
    </div>
  </Router>
    
)



export default Routes;
