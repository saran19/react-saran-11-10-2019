import React, { Component } from "react";
import axios from "axios";
import $ from "jquery";


const site_url = "https://crossword.thehindu.co.in";
const api_url = "https://tai.thehindu.co.in";

  class Header extends Component {
    constructor(props) {
      super(props);
      this.state = {userData:[],user_name:[],user_id: []}
      this.getUserData = this.getUserData.bind(this);
      this.DeviceId = this.DeviceId.bind(this);
      
      };
      
      componentDidMount() {

        this.getUserData();
        

        $(document).ready(function(){
          $(".hamburger").click(function(e){
             e.stopPropagation();
             $(".hamburger").toggleClass("hamCross");
             $(".side-content-lt").toggleClass("active");
             $('.clicknavbtn_div').removeClass("active");
             $('body').toggleClass('cwCustomoverlay');
           });
          $(".close-btn").click(function(e){
            e.stopPropagation();
            $(".hamburger").removeClass("hamCross");
            $('body').removeClass('cwCustomoverlay');
             $(".side-content-lt").removeClass("active");
             });
           
           
           $(".clicknavbtn").click(function(e){
             e.stopPropagation();
             $(".clicknavbtn_div").toggleClass("active");
             $(".side-content-lt").removeClass("active");
             $(".hamburger").removeClass("hamCross");
             $('body').toggleClass('cwCustomoverlay');
           });
           
           $(".clicknavbtn-close-btn").click(function(e){
             e.stopPropagation();
             $(".clicknavbtn_div").removeClass("active");
             $('body').addClass('cwCustomoverlay');
             });
   
           $('body').click( function() {
                 $('.clicknavbtn_div').removeClass("active");
                 $(".side-content-lt").removeClass("active");
                 $(".hamburger").removeClass("hamCross");
                 $('body').removeClass('cwCustomoverlay');
             });
   
             var height = $('.top-nav').outerHeight();
             $(window).scroll(function() {
                     if($(this).scrollTop() > height)
                     {
                         $('.top-nav').css('position','fixed');
                         $('body').css('padding-bottom',height+'px');
                     }
                     else if($(this).scrollTop() <= height)
                     {
                         $('.top-nav').css('position','static');
                         $('body').css('padding-bottom','0');
                     }
             });
             $(window).scroll();
   
         });

      }
    
      DeviceId(){
        var nav = window.navigator;
        var screen = window.screen;
        var  guid = nav.userAgent.replace(/\D+/g, '');
        guid += screen.height || '';
        guid += screen.width || '';
        guid += screen.pixelDepth || '';
        document.cookie = "browserDeviceId="+guid;
        return guid;
      }

      async  getUserData() {

        /*  Find device ID*/
        
       
        const passdata = {
          deviceId: this.DeviceId(),
          siteId: 'CRO-PWI4SI'
        };
       axios.defaults.withCredentials = true;
          await axios.post(api_url + "/taiauth/userInfo/HINDU", passdata).then(response=>{ 
         this.state.userData = response.data;
         const keyCount = Object.keys(response.data).length;
         if(keyCount > 0) {
          document.getElementById("sso-signin").style["display"] = "inline-block";
          document.getElementById("loggedin").style["display"] = "block";
          const userDetails =  JSON.parse(response.data.userInfo);
          //console.log(response.data);
          this.state.user_name = userDetails.FullName;
          this.state.user_id = this.state.userData.userId;
         }else {
          this.state.user_name = "User";
          document.getElementById("loggedout").style["display"] = "block";
         }
    
        this.setState({ userData: this.state.userData, userInfo : this.state.user_name, user : this.state.user_id});
      
      })

      
        }


        logOut() {

          const passdataOut = {
            userId : this.state.user_id,
            deviceId: this.DeviceId(),
            siteId: 'CRO-PWI4SI'
          };
          axios.defaults.withCredentials = true;
          axios.post(api_url + "/taiauth/logout/HINDU", passdataOut).then(response=>{ 
         this.state.userData = response.data;
         console.log(response.data.status);
         if( response.data.status == "success") {
            window.location = site_url;
         }
      
      })

         
        }
    
  
    render() {
    

     return (
      
      <div className="myHeader">
<div className="container-fluid myHeader">
<div className="row">
<div className="page-wrapper">
<div className="top-nav sticky-head">
<div className="toggler-container">
<div className="menu__wrapper hamburger">
<div className="menu__item--hamburger" >
<div className="linetxt">
<div className="boxtxt"></div>
<div className="boxtxt"></div>
<div className="boxtxt"></div>
</div>
<div className="linetxt">
<div className="boxtxt"></div>
<div className="boxtxt"></div>
<div className="boxtxt"></div>
</div>
<div className="linetxt">
<div className="boxtxt"></div>
<div className="boxtxt"></div>
<div className="boxtxt"></div>
</div>
</div>
</div>
<div className="col-md-3 col-sm-1 col-xs-1 hamCwClose">

<div className="side-content-lt">
<div className="close-btn-parent">
<button className="close-btn">x

</button>
</div>
<div className="side-innerContent-lt">
<a href={site_url} className="sidebarLogo"> <img src={site_url + "/images/crossword-logos/cw_navi_logo.png"} alt="" />
</a>
<div className="nav-container-left">
<ul className="nav">
<li className="">
<a href={site_url}>
<span className="text">Crossword Home</span>
<span className="descTextCw">View all crosswords</span>
</a>
</li>
<li>
<a target="_blank" href="https://www.thehindu.com/">
<span className="text">The hindu home</span>
<span className="descTextCw">Return to The Hindu home page</span>
</a>
</li>
<li>
<a href={site_url + "/subscription"}>
<span className="text">crossword subscription</span>
<span className="descTextCw subUserChangeTxt">Subscribe to The Hindu Crosswords</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-cryptic"}>
<span className="text">The Hindu Cryptic</span>
<span className="descTextCw"> The best from our master crossword setters</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-quick"}>
<span className="text">The Guardian Quick </span>
<span className="descTextCw"> An easy brain teaser </span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-everyman"}>
<span className="text">Everyman</span>
<span className="descTextCw"> From the crossword masters at The Observer </span>
</a>
</li>

<li>
<a href={site_url + "/crossword/hindu-one-down"}>
<span className="text">One Down</span>
<span className="descTextCw">Word challenges for our younger players</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-sport-on"}>
<span className="text">Sport On</span>
<span className="descTextCw">Test your knowledge of names and terms from the world of sports</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-sportstar"}>
<span className="text">The Sportstar Crossword </span>
<span className="descTextCw">For the sports trivia fans</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-sudoku"}>
<span className="text">Sudoku</span>
<span className="descTextCw">The world's favourite number game</span>
</a>
</li>
<li>
<a href={site_url + "/crossword/hindu-mini-sudoku"}>
<span className="text">Mini Sudoku</span>
<span className="descTextCw">Number challenges for our younger players</span>
</a>
</li>
<li className="active">
<a target="_blank" href={site_url}>
<span className="text">Clued In</span>
<span className="descTextCw">Discuss clues, grids and more</span>
</a>
</li>
<li>
<a href={site_url + "/about"}>
<span className="text">about us</span>
<span className="descTextCw">A one-stop-shop for interactive puzzles offered by THG Publishing Private Limited.</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
<div className="col-md-6 col-sm-6 col-xs-6">
<div id="logo-crossword" className="logo">
<a href={site_url} className="mobileLogo" style={{display :'none'}}><img src={site_url +"/images/crossword-logos/TH_CW_MW_logo.png"} alt=""/>
</a>
<a href={site_url} className="DeskLogo"> <img src={site_url + "/images/crossword-logos/TH_CW_logo.png"} alt="" />
</a>
</div>
</div>
<div className="col-md-3 col-sm-5 col-xs-5  subscribeDiv">
<a className="cwSubBtn" href={site_url + "/subscription"}>Subscribe</a>
<a id="sso-signin" style={{display : 'none'}}> Hi {this.state.user_name} </a>
<button className="clicknavbtn"><i className="fa fa-user"></i> </button>
<div className="clicknavbtn_div_parent">
<div className="clicknavbtn_div">
<div className="side-content-rt">
<div className="close-btn-parent-rt">
<button className="close-btn-rt">x

</button>
</div>
<div className="side-innerContent-rt">
<div className="row rightSidebarLogoRow">
<div className="col-xs-5">
<a href={site_url + "/profile"} className="rightSidebarLogo"> <img src={site_url + "/images/crossword-logos/user_icon.png"} alt="" />
</a>
</div>
<div className="col-xs-7 nopad"><p><span>Hello</span> <span id="hello-user"> {this.state.user_name} </span></p></div>
</div>
<div className="nav-container-right cw-signin ssologin">
	<ul className="nav" id="loggedin" style={{display: 'none'}}>
    <li className=""><a href={site_url + "/subscription"}>
    <span className="cwRtMenuIcon cwRtMenuIconLn1"></span><span className="text">Subscribe</span></a></li>
    <li><a href={site_url + "/profile"}><span className="cwRtMenuIcon cwRtMenuIconLn2"></span><span className="text">Profile</span></a></li>
    <li><a href={site_url + "/stats"}><span className="cwRtMenuIcon cwRtMenuIconLn3"></span><span className="text">Stats</span></a></li>
    <li><a href={site_url + "/profile?info=subscriptioninfo"}><span className="cwRtMenuIcon cwRtMenuIconLn4"></span><span className="text">Plan</span></a></li>
    <li><a href={site_url + "/profile?info=transactioninfo"}><span className="cwRtMenuIcon cwRtMenuIconLn5"></span><span className="text">Transaction History</span></a></li>
    <li><a href={site_url + "/faq"}><span className="cwRtMenuIcon cwRtMenuIconLn6"></span><span className="text">Help and Support</span></a></li>
    <li><a href={site_url + "/profile?info=feedback"}><span className="cwRtMenuIcon cwRtMenuIconLn7"></span><span className="text">Feedback</span></a></li>
    <li><a href={site_url + "/profile?info=changepassword"}><span className="cwRtMenuIcon cwRtMenuIconLn8"></span><span className="text">Change password</span></a></li>
    <li><a onClick={()=>this.logOut()}><span className="cwRtMenuIcon cwRtMenuIconLn9"></span><span className="text">Sign out</span></a></li>
    <li><img src={site_url + "/images/cwLandingPageImg/Profile_icon_menu_img.png"} alt="" /></li>
    </ul>

    <ul className="nav" id="loggedout" style={{display: 'none'}}>
    <li className=""><a href={site_url + "/login"}><span className="cwRtMenuIcon cwRtMenuIcon1"></span><span className="text">Sign In / Sign Up</span></a></li>
    <li><a href={site_url + "/subscription"}><span className="cwRtMenuIcon cwRtMenuIcon2"></span><span className="text">subscribe</span></a></li>
    <li><a href={site_url + "/faq"}><span className="cwRtMenuIcon cwRtMenuIcon3"></span><span className="text">Help and support</span></a></li>
</ul>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



        
      ); 
      
     
    }
  
  }
  
  
  export default Header;
